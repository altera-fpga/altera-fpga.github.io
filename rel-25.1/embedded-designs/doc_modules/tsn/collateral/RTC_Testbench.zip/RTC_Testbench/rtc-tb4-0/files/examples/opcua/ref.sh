#!/bin/bash
#
# SPDX-License-Identifier: BSD-2-Clause
#

set -e

#
# Command line arguments.
#
INTERFACE=$1
[ -z $INTERFACE ]    && INTERFACE="eth0"       # default: eth0

cd "$(dirname "$0")"

# Start PTP
echo "Starting PTP "
../../scripts/ptp.sh ${INTERFACE}
sleep 1

# Configure flow
echo "Configuring MQPRIO scheduling "
../../scripts/mqprio_flow_sm.sh ${INTERFACE}
sleep 10

# Start one instance of reference application
echo "Starting the TSN Testbench reference application "
timeout 55 ../../reference -c reference_opcua_vid200_sm.yaml > ref1.log

exit 0
