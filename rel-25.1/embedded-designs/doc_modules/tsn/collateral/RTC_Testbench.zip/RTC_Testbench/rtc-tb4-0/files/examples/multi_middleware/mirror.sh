#!/bin/bash
#
# Copyright (C) 2022 Linutronix GmbH
# Author Kurt Kanzenbach <kurt@linutronix.de>
#
# SPDX-License-Identifier: BSD-2-Clause
#

set -e

#
# Command line arguments.
#
INTERFACE=$1
[ -z $INTERFACE ]    && INTERFACE="eth0"       # default: eth0

cd "$(dirname "$0")"

# Start PTP
echo "Starting PTP "
../../scripts/ptp.sh ${INTERFACE}
sleep 1

# Configure flow
echo "Configuring TAPRIO queue scheduling "
../../scripts/taprio_flow_sm.sh ${INTERFACE}
sleep 10

# Start four instances of mirror applications
echo "Starting mirror instance 1 "
timeout 60 ../../mirror -c mirror_vid100_sm.yaml       > mirror1.log &
sleep 1
echo "Starting mirror instance 2 "
timeout 60 ../../mirror -c mirror_opcua_vid200_sm.yaml > mirror2.log &
sleep 1
echo "Starting mirror instance 3 "
timeout 60 ../../mirror -c mirror_opcua_vid300_sm.yaml > mirror3.log &
sleep 1
echo "Starting mirror instance 4 "
timeout 60 ../../mirror -c mirror_avtp_vid400_sm.yaml  > mirror4.log 

exit 0
