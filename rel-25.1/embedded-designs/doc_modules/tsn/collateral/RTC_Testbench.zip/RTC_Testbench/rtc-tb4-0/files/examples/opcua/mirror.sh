#!/bin/bash
#
# SPDX-License-Identifier: BSD-2-Clause
#

set -e

#
# Command line arguments.
#
INTERFACE=$1
[ -z $INTERFACE ]    && INTERFACE="eth0"       # default: eth0

cd "$(dirname "$0")"

# Start PTP
echo "Starting PTP "
../../scripts/ptp.sh ${INTERFACE}
sleep 1

# Configure flow
echo "Configuring MQPRIO scheduling "
../../scripts/mqprio_flow_sm.sh ${INTERFACE}
sleep 10

# Start one instance of mirror application
echo "Starting the TSN Testbench mirror application "
timeout 60 ../../mirror -c mirror_opcua_vid200_sm.yaml > mirror1.log 

exit 0
